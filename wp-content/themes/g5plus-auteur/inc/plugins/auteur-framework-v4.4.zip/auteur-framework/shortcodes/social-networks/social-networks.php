<?php
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_GSF_Social_Networks extends G5P_ShortCode_Base {

}