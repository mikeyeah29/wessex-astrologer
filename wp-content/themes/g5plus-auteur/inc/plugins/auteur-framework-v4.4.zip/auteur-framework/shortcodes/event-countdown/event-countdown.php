<?php
/**
 * Created by PhpStorm.
 * User: Kaga
 * Date: 20/5/2016
 * Time: 3:57 PM
 */
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_GSF_Event_Countdown extends G5P_ShortCode_Base {

}