<?php
/**
 * The template for displaying page-subtitle.php
 *
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Page_Subtitle extends G5P_ShortCode_Base {
}
